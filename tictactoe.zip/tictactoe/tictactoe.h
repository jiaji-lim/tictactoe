/*****************************************************************************/
/*!
\file tictactoe.h
\author Lim Jia Ji
\par email: jiaji.lim\@outlook.com
\date Sept 18, 2020
\brief
This file contains the implementation for the tictactoe program.
Functions includes:
  void TicTacToe::InitBoard()
  void TicTacToe::PlayerInput()
  void TicTacToe::UpdateBoard()
  void TicTacToe::CheckWin()
  bool TicTacToe::CheckGameOver()

*/

/*****************************************************************************/
#include <iostream>
#include <string>

class TicTacToe
{
  char board[3][3];
  int pInput = 0;
  bool xturn = true;  
  bool gameOver = false;
  std::string player1;
  std::string player2;
  char mark;
  int turns = 0;
  
  public: 
 
  TicTacToe();
  void InitBoard();
  void PlayerInput();
  void UpdateBoard();
  void CheckWin();
  bool CheckGameOver();

  
};