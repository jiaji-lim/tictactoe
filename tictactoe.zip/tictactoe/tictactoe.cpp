/*****************************************************************************/
/*!
\file tictactoe.cpp
\author Lim Jia Ji
\par email: jiaji.lim\@outlook.com
\date Sept 18, 2020
\brief
This file contains the implementation for the tictactoe program.
Functions includes:
  void TicTacToe::InitBoard()
  void TicTacToe::PlayerInput()
  void TicTacToe::UpdateBoard()
  void TicTacToe::CheckWin()
  bool TicTacToe::CheckGameOver()

*/

/*****************************************************************************/
#include "tictactoe.h"

/*****************************************************************************/
/*!
Constuctor for the tictactoe class
*/
/*****************************************************************************/
TicTacToe::TicTacToe()
{

}

/*****************************************************************************/
/*!
\fn void TicTacToe::InitBoard()
\brief Function to initialize the board
*/
/*****************************************************************************/
void TicTacToe::InitBoard()
{  
  char gridNo = '1';
  
  std::cout << "Enter name for Player 1:\n";
  std::getline(std::cin, player1);
  std::cout << "Enter name for Player 2:\n";
  std::getline(std::cin, player2);
  
  for(int i = 0; i < 3; ++i)
  {
    for(int j = 0; j < 3; ++j)
    {
      
      board[i][j] = gridNo;
      std::cout << " " << board[i][j];
      if(j < 2)
      {
        std::cout << " |";
      }
      gridNo++;
      
    }
  
    if(i < 3-1)
      std::cout << "\n------------\n";
  }
}

/*****************************************************************************/
/*!
\fn void TicTacToe::PlayerInput()
\brief Function that prompts that its the player's turn and asks for input
*/
/*****************************************************************************/
void TicTacToe::PlayerInput()
{
  int row, col;
  if(xturn)
  {
    mark = 'X';
    std::cout << "\n" << player1 <<", choose a box to place as '" 
    << mark << "' into:\n";
  }
  
  else
  {
    mark = 'O';
    std::cout << "\n" << player2 <<", choose a box to place as '" 
    << mark << "' into:\n";
  } 
  
  std::cin >> pInput;
  
  row = pInput/3;
  col = (pInput%3) - 1;
  
  if(pInput >=1 && pInput <=9)
  {
    if(board[row][col] != 'X' && board[row][col] != 'O')
    {
      board[row][col] = (xturn) ? 'X' : 'O';
      xturn = !xturn;
      ++turns;
    }
    else
    std::cout<< "slot taken!\n";
  }
  
  else
  {
    std::cout << "please enter the number range from 1 - 9 \n";
  }
}
/*****************************************************************************/
/*!
\fn void TicTacToe::UpdateBoard()
\brief Function that update the board every time after player's input
*/
/*****************************************************************************/
void TicTacToe::UpdateBoard()
{
  
  for(int i = 0; i < 3; ++i)
  {
    for(int j = 0; j < 3; ++j)
    {
      std::cout << " " << board[i][j];
      if(j < 2)
      {
        std::cout << " |";
      }
    }
  
    if(i < 3-1)
      std::cout << "\n---------\n";
  }
  
  
}

/*****************************************************************************/
/*!
\fn void TicTacToe::UpdateBoard()
\brief Function to check the winning conditions
*/
/*****************************************************************************/
void TicTacToe::CheckWin()
{
//////////////////////////////////Horizontal/////////////////////////////////
  if(board[0][0] == mark && board[0][1] ==  mark && board[0][2] == mark)
  {
    if(mark == 'X')
    {
      std::cout << "Congratulations " << player1 <<", you have won!";
    }
    else
    {
      std::cout << "Congratulations " << player2 <<", you have won!";
    }
    gameOver = true;
  }
  
  if(board[1][0] == mark && board[1][1] ==  mark && board[1][2] == mark)
  {
    if(mark == 'X')
    {
      std::cout << "Congratulations " << player1 <<", you have won!";
    }
    else
    {
      std::cout << "Congratulations " << player2 <<", you have won!";
    }
    gameOver = true;
  }
  
  if(board[2][0] == mark && board[2][1] ==  mark && board[2][2] == mark)
  {
    if(mark == 'X')
    {
      std::cout << "Congratulations " << player1 <<", you have won!";
    }
    else
    {
      std::cout << "Congratulations " << player2 <<", you have won!";
    }
    gameOver = true;
  }

//////////////////////////////////Vertical/////////////////////////////////

  if(board[0][0] == mark && board[1][0] ==  mark && board[2][0] == mark)
  {
    if(mark == 'X')
    {
      std::cout << "\nCongratulations " << player1 <<", you have won!";
    }
    else
    {
      std::cout << "\nCongratulations " << player2 <<", you have won!";
    }
    gameOver = true;
  }
  
  if(board[0][1] == mark && board[1][1] ==  mark && board[2][1] == mark)
  {
    if(mark == 'X')
    {
      std::cout << "\nCongratulations " << player1 <<", you have won!";
    }
    else
    {
      std::cout << "\nCongratulations " << player2 <<", you have won!";
    }
    gameOver = true;
  }
  
  if(board[0][2] == mark && board[1][2] ==  mark && board[2][2] == mark)
  {
    if(mark == 'X')
    {
      std::cout << "\nCongratulations " << player1 <<", you have won!";
    }
    else
    {
      std::cout << "\nCongratulations " << player2 <<", you have won!";
    }
    gameOver = true;
  }
//////////////////////////////////Diagonal/////////////////////////////////
  if(board[0][0] == mark && board[1][1] ==  mark && board[2][2] == mark)
  {
    if(mark == 'X')
    {
      std::cout << "\nCongratulations " << player1 <<", you have won!";
    }
    else
    {
      std::cout << "\nCongratulations " << player2 <<", you have won!";
    }
    gameOver = true;
  }
  
  if(board[0][2] == mark && board[1][1] ==  mark && board[2][0] == mark)
  {
    if(mark == 'X')
    {
      std::cout << "\nCongratulations " << player1 <<", you have won!";
    }
    else
    {
      std::cout << "\nCongratulations " << player2 <<", you have won!";
    }
    gameOver = true;
  }
  
  if(turns == 9 && !gameOver)
  {
    std::cout << "\nIts a draw!\n";
    gameOver = true;
  }
  
 }
/*****************************************************************************/
/*!
\fn bool TicTacToe::CheckGameOver()
\brief Function to check the winning conditions
*/
/*****************************************************************************/
bool TicTacToe::CheckGameOver()
{
  return gameOver;
}

int main()
{
  
  TicTacToe ttt;
  
  ttt.InitBoard();
  
  while(!ttt.CheckGameOver())
  {
    ttt.PlayerInput();
    ttt.UpdateBoard();
    ttt.CheckWin();
  
  }
  
  
  return 0;
}

